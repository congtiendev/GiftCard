// require(['jquery'], function ($) {
//     $(document).ready(function () {
//         const enableGiftCardValue = parseInt($('#giftcard_config_general_enable_giftcard').val());
//         const giftCardCodeMenu = $('[data-ui-id="menu-mageplaza-giftcard-giftcard-code"]');
//
//         if (enableGiftCardValue && enableGiftCardValue !== 1) {
//             giftCardCodeMenu.hide();
//         } else {
//             giftCardCodeMenu.show();
//         }
//
//         $('#giftcard_config_general_enable_giftcard').change(function () {
//             if (parseInt($(this).val()) !== 1) {
//                 giftCardCodeMenu.hide();
//             } else {
//                 giftCardCodeMenu.show();
//             }
//         });
//     });
// });
